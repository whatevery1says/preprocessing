# Topic Bubbles

## Info

Authors: Sihwa Park, Jeremy Douglass, Scott Kleinman, Lindsay Thomas
Copyright: copyright 2019, The WE1S Project
License: MIT
Version: 1.2.1
Email: lindsaythomas@miami.edu
Last Update: 2020-07-25

## About This Module

This module creates a topic bubbles visualization from dfr-browser data generated in the dfr-browser notebook or from model data generated in the topic modeling notebook. This module uses scripts originally written by Sihwa Park for the WE1S project. For more information on Park's script, see [Park's topic bubbles Github repo](https://github.com/sihwapark/topic-bubbles) and the `README.md` located in this module's `tb_scripts` folder.

## Notebooks

`create_topic_bubbles.ipynb`: The main notebook for the module. Notebook for creating a topic bubbles visualization. Provides an interface to the code located in `scripts/create_topic_bubbles.py`, `scripts/create_dfrbrowser.py`, and `scripts/publish.py`.

## User Guide

### Settings

The **Settings** cell defines paths and important variables used to create a topic bubbles visualization. The default settings will create a folder inside the topic_bubbles module for each topic model in your project or for a selection of models. In most cases, you will not need to change the default settings.

### Create Topic Bubbles with Dfr-Browser
If you ran the `create_dfrbrowser` notebook in this project to create dfr-browser visualizations for your models, the next cells will import data produced via that notebook into the topic bubbles module. If you did not run the `create_dfrbrowser` notebook, you should skip to the next section: **"Create Topic Bubbles without Dfr-Browser"**.

By default, this notebook is set to create topic bubble browsers for all of the models you produced in Notebook 2 (`02_model_topics.ipynb`). If you would like to select only certain models to produce browsers for, make those selections in the notebook. Otherwise leave the value of the `selection` variable set to `All`, which is the default. 

The `create_topicbubbles_dfrbrowser()` function copies the files you need from your dfr-browser visualizations and creates topic bubbles visualizations for your selected models. This function assumes your project is set up according to WE1S standard format (and thus was created using the WE1S `new_project` notebook). It prints output from Goldstone's prepare_data.py script to the notebook cell. 

### Create Topic Bubbles without Dfr-Browser
If you have not created dfr-browsers for your project, you should run the cells in this section of the notebook to create your topic bubbles visualizations.

### Create Metadata: Create DFR csv metadata from json files
The `dfrb_metadata()` function opens up each json in your project's json directory and grabs the metadata information dfr-browser needs. It creates both the `metadata_csv_file` file and the `browser_meta_file_temp` file. It assumes your project is set up according to WE1S standard format (and thus was created using the WE1S `new_project` notebook).

### Create Files Needed for Topic Bubbles
By default, this notebook is set to create topic bubble browsers for all of the models you produced in Notebook 2 (`02_model_topics.ipynb`). If you would like to select only certain models to produce browsers for, make those selections in the notebook. Otherwise leave the value of the `selection` variable set to `All`, which is the default. 

The `get_model_state()` function grabs the filepaths of model subdirectories in order to visualize and their state and scaled files. It assumes your project is set up according to WE1S standard format (and thus was created using the WE1S `new_project` notebook). You can also set values for `subdir_list`, `state_file_list`, and `scaled_file_list` manually in the cell below the next one.

The `create_topicbubbles()` function creates the files needed for topic bubbles, using the model state and scaled files for all selected modelsand Goldstone's prepare_data.py script (to produce the dfr-browser files needed for topic bubbles). It prints output from Goldstone's prepare_data.py script to the notebook cell. 

### View Topic Bubbles
The `Publish()` class publishes your topic bubbles visualizations to the `view` container and makes them available for viewing on port 10002 (this port is configurable under `config/config.py` in your project folder). If you are working for the WE1S project and have access to full-text data, these visualizations will not contain links to full-text data.

### Zip Topic Bubles: Create zipped copies of your visualizations for export
This section zips up your topic bubbles visualizations for serving on a different machine or server. By default, browsers for all available models will be zipped. If you wish to zip only one model, change the `models` setting to indicate the name of the model folder (e.g. `'topics25'`). If you wish to zip more than one model, but not all, provide a list in square brackets (e.g. `['topics25', 'topics50']`). This section also includes instructions for downloading and running your topic bubble visualization(s) on a different machine (i.e., outside of the WE1S container system).

## Module Structure

📦topic_bubbles
 ┣ 📂scripts
 ┃ ┣ 📜create_dfrbrowser.py
 ┃ ┣ 📜create_topic_bubbles.py
 ┃ ┣ 📜zip.py
 ┣ 📂tb_scripts
 ┃ ┣ 📂css
 ┃ ┃ ┗ 📜style.css
 ┃ ┣ 📂data
 ┃ ┃ ┗ 📜config.json
 ┃ ┣ 📂img
 ┃ ┃ ┣ 📜screenshot.png
 ┃ ┃ ┗ 📜we1s_logo.png
 ┃ ┣ 📂js
 ┃ ┃ ┣ 📜d3-mouse-event.js
 ┃ ┃ ┣ 📜script.js
 ┃ ┃ ┣ 📜utils.min.js
 ┃ ┃ ┗ 📜worker.min.js
 ┃ ┣ 📂lib
 ┃ ┣ 📜index.html
 ┃ ┣ 📜LICENSE
 ┃ ┗ 📜README.md
 ┣ 📜create_topic_bubbles.ipynb
 ┗ 📜README.md
