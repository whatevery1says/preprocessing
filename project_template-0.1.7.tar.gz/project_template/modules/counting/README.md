# Counting

## Info

Authors: Scott Kleinman and Lindsay Thomas
Copyright: copyright 2019, The WE1S Project
License: MIT
Version: 2.0
Email: lindsaythomas@miami.edu
Last Update: 2020-10-08

## About This Module

This module contains four notebooks for counting various aspects of project data. The notebooks allow you to count project documents (`count_documents.ipynb`), tokens (as uni-, bi-, and/or trigrams) (`count_tokens.ipynb`), and to grab summary statistics of documents, tokens, etc in the project (`vocab.ipynb`). The `vocab.ipynb` notebook requires that your json data files contain a `bag_of_words` field with term counts. If you have not previously generated this field when you imported your data, you can do so using `tokenize.ipynb`, which leverages [spaCy's tokenizer](https://spacy.io). The `count_tokens.ipynb` notebook uses a custom tokenizer based on the tokenizer available in [NLTK](https://www.nltk.org/). This differs from the tokenizer WE1S uses in its preprocessing pipeline and in its topic modeling pipeline, which only tokenizes unigrams. As a result, some features of the `count_tokens.ipynb` notebook will not work if you do not have access to full-text data. 

The `count_tokens.ipynb` notebook allows users to configure their text input field -- in other words, you can tell the code where to look to find the text you want to process. You have three options for this: the `content` field, the `bag_of_words` field, or the `features` field. The code expects data in these fields to be in the following formats:

* `content`: Full, plain-text data, stored as a string in each document.
* `bag_of_words`: A bag of words dictionary, where each key is a unique unigram, and each value is a count of the number of times that token appears in the document. The `import` module allows users to create the `bag_of_words` field and add it to their project data. Data is alphabetized by default, meaning the bags are not reconstructable.
* `features`: This field is inserted by the WE1S preprocessor using spaCy, and the recommended `content_field` to use if working with WE1S public data. It is a list of lists that contains information of the following kinds about each token in the document: `["TOKEN", "NORM", "LEMMA", "POS", "TAG", "STOPWORD", "ENTITIES"]`. NORM is a lowercased version of the token. LEMMA is the dictionary headword (so the lemma of "going" is "go"). POS is the part of speech according to spaCy's [taxonomy](https://spacy.io/api/annotation#pos-tagging). TAG is the equivalent in the Penn-Treebank system. ENTITIES is a named entity as classified [here](https://spacy.io/api/annotation#named-entities). Lemmas, POS, tags, and entities are all predicted by spaCy using its language model. STOPWORD is whether or not the lower case form of a token is classed as a stop word in a stoplist. For WE1S data, this is the WE1S Standard Stoplist. spaCy has its own stoplist, and users can also supply their own. Alphabetized by default.

If your json documents do not have a `content` field (if you are using publicly released WE1S data, for instance), and you are using the `bag_of_words` or `features` field as your text input, you will not be able to use some of the functions available in the `count_tokens.ipynb` notebook. You will also only be able to count unigrams (since all word bags or features tables are alphabetized and thus bigrams and trigrams are not reconstructable).

Because the `count_tokens.ipynb` notebook relies on a custom tokenizer hand-crafted for WE1S data, it may not be suitable for all researchers. It is likely possible to get better, cleaner counts of many tokens using out of the box tokenizers available through NLTK or spaCy, for instance.

## Notebooks

- `count_tokens.ipynb`: Notebook for token counting, frequency distributions, tf-idf scores, and association metrics across documents in the project.
- `count_documents.ipynb`: Notebook for counting and visualizing document and tag totals by year and source within the project.
- `tokenize.ipynb`: Notebook for tokenizing data and saving term counts in a `bag_of_words` field in json data files.
- `vocab.ipynb`: Notebook for building a single `Vocab` object from which information about the vocab can be accessed (use to gather summary statistics about your project json documents).

## User Guide

What follows are brief summaries of each notebook in this module. The notebooks themselves are flexible and have a wide range of functionality. For this reason, they are heavily documented and provide information about how to use them and what their different sections mean. Please refer to the notebooks for instructions about how to use the notebooks.

### `count_tokens.ipynb`  

This notebook provides a series of functions for counting the number of documents in a project containing a specific word or phrase; for obtaining uni-, bi-, and trigram frequency counts and relative frequencies; for obtaining tf-idf scores for specific words; and for utilizing some basic collocation metrics for determining the relationships between words in a project.

Some examples of questions that you can use this module to explore:

- How many documents in my project contain the phrase "first-generation"?
- What is the (raw and/or relative) frequency of the word "college" within a specific document in my project, and/or across all of the project's documents? What is the frequency of the phrase "private college"? What about "private college students"?
- What are some of the most distinctive words for given documents in my project? - - What are some of the most important words for understanding the content of documents in my project overall?
- How strongly associated is the word "private" with the word "college" in my project?
- What are some meaningful or important collocations (bigrams or trigrams, or 2- or 3-word phrases) in my project, and how can I determine and describe what it means for them to be "meaningful" or "important" in different ways?

You can also download a csv containing the bibliographic information of all project documents containing a specific word or phrase for easier viewing in dfr-browser and/or to obtain individual filenames for documents you want to explore further in this notebook; and to download all documents in your project containing a specific word or phrase as `.json` or `.txt` documents for further exploration using tools like AntConc.

### `count_documents.ipynb` 

This notebook counts the number of documents per unique source per year in the project. It offers two different methods of counting and is organized into numbered sections. Each counting method offers does the same thing, but in a different way (one relies on dfr-browser metadata, and one does not). You can also load an existing dataframe of document counts for use in the notebook. The notebook also includes a few options for saving and visualizing document totals, for counting the number of documents without a publication date (important for data collected via Lexis Nexis), and for counting the number of documents associated with a specific metadata field in your project.

### `tokenize.ipynb`

Normally text analysis tools have to divide a text into countable "tokens" (most frequently words). This process is called tokenization. This cell allows you to pre-tokenize your data so that other tools do not need to take this step. It generates a dictionary of token-count pairs such as `{"cat": 3, "dog": 2}` for each of your JSON files. This dictionary is appended to the JSON file in the `bag_of_words` field.

This notebook offers two tokenization methods. The default method is strips all non-alphanumeric characters and then divides the text into tokens on white space. Alternatively, you can use the <a href="https://spacy.io/" target="_blank">spaCy</a> Natural Language Processing library to tokenize based on spaCy's language model. spaCy extracts linguistic `features` from your text, not only tokens but parts of speech and named entities. This is instrinsically slower and may require a lot of memory for large texts. To use WE1S's custom spaCy tokenizer, set `method='we1s'`. If your text has been previously processed by spaCy and there is a `features` table in your JSON file, the tokenizer will attempt to use it to build the `bag_of_words` dictionary. 

Errors will be logged to the path you set for the log_file.

### `vocab.ipynb` 

This notebook allows you to build a single json vocab file containing term counts for all the documents in your project's json directory. It also allows you to access information about the vocab in a convenient manner. If your data does not already have `bag_of_words` fields, you should run `tokenize.ipynb` first.

## Module Structure

📦counting
┣ 📂scripts
 ┃ ┣ 📜count_docs.py
 ┃ ┣ 📜count_tokens.py
 ┃ ┣ 📜tokenizer.py
 ┃ ┣ 📜vocab.py
 ┣ 📜count_documents.ipynb
 ┣ 📜count_tokens.ipynb
 ┣ 📜README.md
 ┣ 📜tokenize.ipynb
 ┗ 📜vocab.ipynb
