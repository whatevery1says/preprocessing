# Comparing

## Info

Authors: Lindsay Thomas
Copyright: copyright 2020, The WE1S Project
License: MIT
Version: 2.0
Email: lindsaythomas@miami.edu
Last Update: 2020-07-01

## About This Module

This module allows you to compare two corpora to one another to discover how, and how much, they differ. These two corpora may be data from two different projects, or two sets of data from within the same project (i.e., data classified as being about the humanities vs. data classified as being about science). The module performs this comparison using the Wilcoxon rank sum test, a statistical test that determines if two samples (i.e., the relative frequencies of shared words in two different datasets) are taken from populations that are significantly different from one another (meaning, if they have different distributions). When used to compare word frequency data from two different corpora, it helps you to determine what the most "significant" words in each corpus are.

For more on the Wilcoxon rank sum test in the context of corpus analytics, see this article: https://academic.oup.com/dsh/article-abstract/31/2/374/2462752.

## Notebooks

- `compare-word-frequencies.ipynb`: Main notebook for the module. Provides an interface to the code in `compare_word_frequencies.py` script.

## User Guide

To run the code in this module, you must have used the `topic_modeling` module to create a bag of words plain-text file of all of your project data. The format of this file is described under section "1. SELECT DATA" in the `compare_word_frequencies.ipyb` notebook in this module.

The `compare_word_frequencies.ipynb` notebook provides ways to select data from 2 different projects, from 2 different categories within the same project, and to randomly select documents from within these categories. However, you must know how to obtain the filenames of the documents corresponding to the categories you want to compare. You need to be able to create 2 lists of document filenames, 1 corresponding to each category. The filenames in each list file must each be on their own line. 

Once you have these lists of filenames, you are ready to begin. Please refer to the notebooks for additional instructions about how to use the notebook.

## Module Structure

📦comparing
 ┣ 📂data
 ┣ 📂results
 ┣ 📂scripts
 ┃ ┣ 📜compare_word_frequencies.py
 ┣ 📜compare-word-frequencies.ipynb
 ┗ 📜README.md
