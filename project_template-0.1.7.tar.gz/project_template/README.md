### Template Information

**Name:** multiple_topics_template
**Version:** 1.0.0
**Contributors:** Jeremy Douglass, Scott Kleinman, Lindsay Thomas
**Date:** 2020-07-03